Hello World Threejs

Camera control:
Roate: Drag + left mouse button Zoom: 
Drag + middle mouse button Pan: Drag + right mouse button