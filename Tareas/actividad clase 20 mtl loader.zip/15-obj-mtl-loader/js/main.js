"use strict"
var canvas;
var engine;
var scene;
var mesh = null;
var camera;
var lightFront;
var multiview = false;
var controlCamera;
var guiControls;

function update()
{
    mesh.rotation.y = mesh.rotation.y + 0.01;
}

function renderLoop() 
{
    engine.setViewport(0, 0, window.innerWidth, window.innerHeight);
    engine.clear();
    if(mesh)
    {   
        camera.aspect = canvas.width / canvas.height;
        camera.updateProjectionMatrix();
        engine.setScissor(0, 0, window.innerWidth, window.innerHeight);
        engine.render(scene, camera);
        
        update();
    }
    requestAnimationFrame(renderLoop);
}


function main()
{ 
    // CANVAS
    canvas = document.getElementById("canvas");

    // RENDERER ENGINE
    engine = new THREE.WebGLRenderer({canvas: canvas});
    engine.setSize(window.innerWidth, window.innerHeight);
    engine.setClearColor(new THREE.Color(0.2, 0.2, 0.35), 1.);   

     // SCENE
    scene = new THREE.Scene();

    // CAMERA
    camera = new THREE.PerspectiveCamera(60., canvas.width / canvas.height, 0.01, 1000.);  // CAMERA  
    camera.lookAt(scene.position);
    camera.up.set(0., 1., 0.);
    controlCamera = new THREE.OrbitControls(camera, canvas);      

    // LIGHTS 
    lightFront = new THREE.DirectionalLight();
    lightFront.position.set(0, 0, 100);
    var lightBack = new THREE.DirectionalLight();
    lightBack.position.set(0., 0., -100.).normalize();
    var lightRight = new THREE.DirectionalLight();
    lightRight.position.set(100., 0., 0.);
    var lightLeft = new THREE.DirectionalLight();
    lightLeft.position.set(-100., 0., 0.);

    // FLOOR
    var floor = new THREE.Mesh(new THREE.PlaneGeometry(500, 500, 10, 10), new THREE.MeshBasicMaterial({wireframe: true, color: "grey"}));
    floor.rotation.x = -Math.PI / 2.;

     // AXES HELPER
    var axesHelper = new THREE.AxesHelper(20);
    axesHelper.position.set(0., 0.01, 0.);

    // SCENEGRAPH   
    //scene.add(floor);   
    //scene.add(axesHelper);
    scene.add(camera); 
    scene.add(lightFront);
    scene.add(lightRight);
    scene.add(lightLeft);
    scene.add(lightBack);

    // GUI
    guiControls = { 
                    lightFrontColor: "#ffffff",
                    lightFrontIntensity: 0.75,
                    loadFile : function() 
                                { 
                                    document.getElementById('inputFile').click();
                                }
                  };
    var datGui = new dat.GUI();  
    var sliderLightFrontIntensity = datGui.add(guiControls, 'lightFrontIntensity').min(0.).max(1.).step(0.1).name('Front Light Intensity');
    var colorLightFront = datGui.addColor(guiControls, 'lightFrontColor').name('Front Light Color');
    datGui.add(guiControls, 'loadFile').name('Load OBJ 3D Model');
    datGui.close();

     // EVENT-HANDLERS
    window.addEventListener('resize', resizeWindow, false);
    colorLightFront.onChange(colorLightFrontOnChange);
    sliderLightFrontIntensity.onChange(sliderLightFrontIntensityOnChange);
    var inputFile = document.getElementById("inputFile");
    inputFile.addEventListener("change", inputFileEventListener, false);

    // ACTION
    requestAnimationFrame(renderLoop);           
}




