// Resets the canvas dimensions to match window
function resizeWindow(event)
{   
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    engine.setSize(canvas.width, canvas.height);
    camera.aspect = canvas.width / canvas.height;
    camera.updateProjectionMatrix();
}

function colorLightFrontOnChange(event)
{
    lightFront.color = new THREE.Color(event);
}

function sliderLightFrontIntensityOnChange(event)
{
    lightFront.intensity = event;
}

function inputFileEventListener() 
{
    if(mesh)
    { 
        mesh.visible = false;
    }
    var objFile = this.files[0].name;
    var name = objFile.substring(0, objFile.length - 4);
    // 3D MODEL
    var mtlLoader = new THREE.MTLLoader();
    mtlLoader.setPath("./models/obj/" + name + "/");
    mtlLoader.load(name + ".mtl", function(materials) 
                                {
                                    materials.preload();
                                    var objLoader = new THREE.OBJLoader();
                                    objLoader.setMaterials(materials);
                                    objLoader.setPath( "./models/obj/" + name + "/");
                                    objLoader.load(objFile, function (object) 
                                                                {
                                                                    mesh = object;
                                                                    mesh.name = name;

                                                                    var box3 = new THREE.Box3();
                                                                    var bBox = box3.setFromObject(mesh);
                                                                    var center = bBox.getCenter(new THREE.Vector3());
                                                                    var size = box3.getSize(new THREE.Vector3());
                                                                    object.position.set(-center.x, -center.y, -center.z);
                                                                    camera.position.set(0, 0, 2.*size.z);
                                                                    scene.add(mesh);
                                                                });
                                });
}



